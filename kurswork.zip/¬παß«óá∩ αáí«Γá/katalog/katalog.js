
const priceFromInput = document.getElementById("price-from");
const priceToInput = document.getElementById("price-to");
const sortBySelect = document.getElementById("sort-by");
const manufactureSelect = document.getElementById("data-manufacture");
const memoryFilterSelect = document.getElementById("memory-filter");
const memoryTypeFilterSelect = document.getElementById("memory-type-filter");
const gpuManufacturerSelect = document.getElementById("manufacturer-filter");

const productsContainer = document.querySelector(".featured-products");
const products = Array.from(productsContainer.getElementsByClassName("featured-product"));


function filterProducts() {
    const priceFrom = parseFloat(priceFromInput.value) || 0;
    const priceTo = parseFloat(priceToInput.value) || Infinity;
    const selectedManufacturer = manufactureSelect.value;
    const selectedMemory = memoryFilterSelect.value;
    const selectedMemoryType = memoryTypeFilterSelect.value;
    const selectedGpuManufacturer = gpuManufacturerSelect.value;

    products.forEach(product => {
        const priceElement = product.querySelector(".product-details > div");
        const priceText = priceElement.innerText;
        const price = parseFloat(priceText.replace('Цена: ', '').replace(' BYN', ''));

        const manufacturer = product.getAttribute("data-manufacturer");
        const memory = product.getAttribute("data-memory");
        const memoryType = product.getAttribute("data-memory-type");
        const gpuManufacturer = product.getAttribute("data-gpu-manufacturer");

        const isVisible = (
            price >= priceFrom && price <= priceTo &&
            (!selectedManufacturer || manufacturer === selectedManufacturer) &&
            (!selectedMemory || memory === selectedMemory) &&
            (!selectedMemoryType || memoryType === selectedMemoryType) &&
            (!selectedGpuManufacturer || gpuManufacturer === selectedGpuManufacturer)
        );

        product.style.display = isVisible ? "block" : "none";
    });
}

function sortProducts() {
    const sortBy = sortBySelect.value;

    products.sort((a, b) => {
        const priceAElement = a.querySelector(".product-details > div");
        const priceBElement = b.querySelector(".product-details > div");
        
        const priceA = parseFloat(priceAElement.innerText.replace('Цена: ', '').replace(' BYN', ''));
        const priceB = parseFloat(priceBElement.innerText.replace('Цена: ', '').replace(' BYN', ''));

        if (sortBy === "low-to-high") {
            return priceA - priceB;
        } else {
            return priceB - priceA;
        }
    });


    products.forEach(product => {
        productsContainer.appendChild(product);
    });
}

priceFromInput.addEventListener("input", filterProducts);
priceToInput.addEventListener("input", filterProducts);
sortBySelect.addEventListener("change", sortProducts);
manufactureSelect.addEventListener("change", filterProducts);
memoryFilterSelect.addEventListener("change", filterProducts);
memoryTypeFilterSelect.addEventListener("change", filterProducts);
gpuManufacturerSelect.addEventListener("change", filterProducts);


filterProducts();
sortProducts();
