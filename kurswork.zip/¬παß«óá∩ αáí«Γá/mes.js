document.addEventListener('DOMContentLoaded', function() {
    // Получаем модальное окно и элементы
    const modal = document.getElementById('messageModal');
    const sendMessageButton = document.querySelector('.settmesage');
    const closeButton = document.querySelector('.close-button');
    const messageForm = document.getElementById('messageForm');

    // Функция для открытия модального окна
    function openModal() {
        modal.style.display = 'flex';
    }

    // Функция для закрытия модального окна
    function closeModal() {
        modal.style.display = 'none';
    }

    // Добавляем слушатель событий на кнопку "Отправить сообщение"
    sendMessageButton.addEventListener('click', function(event) {
        event.preventDefault();
        openModal();
    });

    // Добавляем слушатель событий на кнопку закрытия
    closeButton.addEventListener('click', function() {
        closeModal();
    });

    // Закрытие модального окна при клике вне окна
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeModal();
        }
    });

    // Добавляем обработчик события для отправки формы
    messageForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Останавливаем стандартную отправку формы

        // Получаем значения полей
        const message = document.getElementById('message').value;
        const orderNumber = document.getElementById('orderNumber').value;
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;

        // Регулярные выражения для валидации
        const orderNumberRegex = /^\d+$/; // Только цифры
        const nameRegex = /^[A-Za-zА-Яа-яёЁ]+$/; // Только буквы (русские или латинские)
        const phoneRegex = /^\d+$/; // Только цифры

        // Проверяем соответствие полей регулярным выражениям
        const isValidOrderNumber = orderNumberRegex.test(orderNumber);
        const isValidName = nameRegex.test(name);
        const isValidPhone = phoneRegex.test(phone);

        // Если все поля заполнены и соответствуют критериям валидации
        if (message && isValidOrderNumber && isValidName && isValidPhone && email) {
            // Отображаем сообщение об отправке
            alert("Ваше сообщение отправлено.");
            
            // Закрываем модальное окно
            closeModal();
        } else {
            // Сообщаем о проблеме с заполнением
            alert("Пожалуйста, заполните все поля корректно перед отправкой.");
        }
    });
});
